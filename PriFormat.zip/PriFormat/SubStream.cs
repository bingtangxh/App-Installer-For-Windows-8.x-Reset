﻿using System;
using System.IO;

namespace PriFormat
{
	/// <summary>
	/// Read-only sub-stream view on a base stream.
	/// Does NOT own the base stream by default.
	/// </summary>
	public sealed class SubStream: Stream, IDisposable
	{
		private Stream _baseStream;
		private readonly long _subPosition;
		private readonly long _subLength;
		private readonly bool _leaveOpen;
		private bool _disposed;
		public SubStream (Stream baseStream, long subStreamPosition, long subStreamLength)
			: this (baseStream, subStreamPosition, subStreamLength, true)
		{
		}
		public SubStream (
			Stream baseStream,
			long subStreamPosition,
			long subStreamLength,
			bool leaveOpen)
		{
			if (baseStream == null)
				throw new ArgumentNullException ("baseStream");
			if (!baseStream.CanSeek)
				throw new ArgumentException ("Base stream must support seeking.", "baseStream");
			if (subStreamPosition < 0)
				throw new ArgumentOutOfRangeException ("subStreamPosition");
			if (subStreamLength < 0)
				throw new ArgumentOutOfRangeException ("subStreamLength");
			if (baseStream.Length < subStreamPosition + subStreamLength)
				throw new ArgumentException ("SubStream range exceeds base stream length.");
			_baseStream = baseStream;
			_subPosition = subStreamPosition;
			_subLength = subStreamLength;
			_leaveOpen = leaveOpen;
			_baseStream.Position = _subPosition;
		}

		public long SubStreamPosition
		{
			get { return _subPosition; }
		}
		public override bool CanRead
		{
			get { return !_disposed && _baseStream.CanRead; }
		}
		public override bool CanSeek
		{
			get { return !_disposed && _baseStream.CanSeek; }
		}
		public override bool CanWrite
		{
			get { return false; }
		}
		public override long Length
		{
			get
			{
				EnsureNotDisposed ();
				return _subLength;
			}
		}
		public override long Position
		{
			get
			{
				EnsureNotDisposed ();
				return _baseStream.Position - _subPosition;
			}
			set
			{
				EnsureNotDisposed ();
				if (value < 0 || value > _subLength)
					throw new ArgumentOutOfRangeException ("value");

				_baseStream.Position = _subPosition + value;
			}
		}
		public override void Flush ()
		{
			// read-only, no-op
		}
		public override int Read (byte [] buffer, int offset, int count)
		{
			EnsureNotDisposed ();

			if (buffer == null)
				throw new ArgumentNullException ("buffer");
			if (offset < 0 || count < 0)
				throw new ArgumentOutOfRangeException ();
			if (buffer.Length - offset < count)
				throw new ArgumentException ("Invalid offset/count.");

			long remaining = _subLength - Position;
			if (remaining <= 0)
				return 0;

			if (count > remaining)
				count = (int)remaining;

			return _baseStream.Read (buffer, offset, count);
		}
		public override long Seek (long offset, SeekOrigin origin)
		{
			EnsureNotDisposed ();

			long target;
			switch (origin)
			{
				case SeekOrigin.Begin:
					target = offset;
					break;
				case SeekOrigin.Current:
					target = Position + offset;
					break;
				case SeekOrigin.End:
					target = _subLength + offset;
					break;
				default:
					throw new ArgumentException ("Invalid origin.", "origin");
			}

			if (target < 0 || target > _subLength)
				throw new IOException ("Attempted to seek outside the substream.");

			_baseStream.Position = _subPosition + target;
			return target;
		}
		public override void SetLength (long value)
		{
			throw new NotSupportedException ();
		}
		public override void Write (byte [] buffer, int offset, int count)
		{
			throw new NotSupportedException ();
		}
		protected override void Dispose (bool disposing)
		{
			if (!_disposed)
			{
				if (disposing)
				{
					if (!_leaveOpen && _baseStream != null)
						_baseStream.Dispose ();
				}

				_baseStream = null;
				_disposed = true;
			}

			base.Dispose (disposing);
		}
		private void EnsureNotDisposed ()
		{
			if (_disposed)
				throw new ObjectDisposedException ("SubStream");
		}
	}
}
