﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

namespace PriFormat
{
	public static class StreamHelper
	{
		public static Stream FromIStream (IStream comStream)
		{
			if (comStream == null) return null;
			return new ComIStreamWrapper (comStream);
		}

		public static Stream FromIStream (IntPtr comStreamPtr)
		{
			if (comStreamPtr == IntPtr.Zero) return null;

			IStream comStream =
				(IStream)Marshal.GetObjectForIUnknown (comStreamPtr);

			return new ComIStreamWrapper (comStream);
		}
	}

	internal sealed class ComIStreamWrapper: Stream
	{
		private IStream _stream;
		private long _position;

		public ComIStreamWrapper (IStream stream)
		{
			if (stream == null)
				throw new ArgumentNullException ("stream");

			_stream = stream;

			// 初始化当前位置
			try
			{
				_position = InternalSeek (0, SeekOrigin.Current);
			}
			catch
			{
				_position = 0;
			}
		}

		public override bool CanRead => _stream != null;
		public override bool CanSeek => _stream != null;
		public override bool CanWrite => _stream != null;

		public override long Length
		{
			get
			{
				System.Runtime.InteropServices.ComTypes.STATSTG stat;
				_stream.Stat (out stat, 1); // STATFLAG_NONAME
				return stat.cbSize;
			}
		}

		public override long Position
		{
			get { return _position; }
			set { Seek (value, SeekOrigin.Begin); }
		}

		public override void Flush ()
		{
			_stream.Commit (0); // STGC_DEFAULT
		}

		public override int Read (byte [] buffer, int offset, int count)
		{
			if (buffer == null)
				throw new ArgumentNullException ("buffer");
			if (offset < 0 || count < 0 || buffer.Length - offset < count)
				throw new ArgumentOutOfRangeException ();

			byte [] target = buffer;
			if (offset != 0)
				target = new byte [count];

			IntPtr pcbRead = Marshal.AllocHGlobal (sizeof (int));
			try
			{
				_stream.Read (target, count, pcbRead);
				int read = Marshal.ReadInt32 (pcbRead);

				if (offset != 0 && read > 0)
					Buffer.BlockCopy (target, 0, buffer, offset, read);

				_position += read;
				return read;
			}
			finally
			{
				Marshal.FreeHGlobal (pcbRead);
			}
		}

		public override void Write (byte [] buffer, int offset, int count)
		{
			if (buffer == null)
				throw new ArgumentNullException ("buffer");
			if (offset < 0 || count < 0 || buffer.Length - offset < count)
				throw new ArgumentOutOfRangeException ();

			byte [] src = buffer;
			if (offset != 0)
			{
				src = new byte [count];
				Buffer.BlockCopy (buffer, offset, src, 0, count);
			}

			IntPtr pcbWritten = Marshal.AllocHGlobal (sizeof (int));
			try
			{
				_stream.Write (src, count, pcbWritten);
				int written = Marshal.ReadInt32 (pcbWritten);
				_position += written;
			}
			finally
			{
				Marshal.FreeHGlobal (pcbWritten);
			}
		}

		public override long Seek (long offset, SeekOrigin origin)
		{
			_position = InternalSeek (offset, origin);
			return _position;
		}

		private long InternalSeek (long offset, SeekOrigin origin)
		{
			IntPtr posPtr = Marshal.AllocHGlobal (sizeof (long));
			try
			{
				_stream.Seek (offset, (int)origin, posPtr);
				return Marshal.ReadInt64 (posPtr);
			}
			finally
			{
				Marshal.FreeHGlobal (posPtr);
			}
		}

		public override void SetLength (long value)
		{
			_stream.SetSize (value);
		}

		protected override void Dispose (bool disposing)
		{
			if (_stream != null)
			{
				Marshal.ReleaseComObject (_stream);
				_stream = null;
			}
			base.Dispose (disposing);
		}
	}
}
